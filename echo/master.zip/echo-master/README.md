# echo
For controlling local devices with the Amazon Echo.

Instructions for installation and usage [available on Instructables here](http://www.instructables.com/id/Hacking-the-Amazon-Echo/)

Brought to you by [FabricateIO](http://fabricate.io)
